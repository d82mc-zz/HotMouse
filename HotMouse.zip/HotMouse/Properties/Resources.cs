﻿// Decompiled with JetBrains decompiler
// Type: HotMouse.Properties.Resources
// Assembly: HotMouse, Version=0.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: BCDF7B6D-2DF3-46E7-87F7-42EECC13BAFB
// Assembly location: C:\Users\d82mc\AppData\Local\Apps\2.0\JOHL5TOD.DEP\43HDHM9P.HR1\hotm..tion_a6765aedf8daf2cc_0002.0003_8a45d257b7895c72\HotMouse.exe

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace HotMouse.Properties
{
  [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "15.0.0.0")]
  [DebuggerNonUserCode]
  [CompilerGenerated]
  internal class Resources
  {
    private static ResourceManager resourceMan;
    private static CultureInfo resourceCulture;

    [SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
    internal Resources()
    {
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager ResourceManager
    {
      get
      {
        if (HotMouse.Properties.Resources.resourceMan == null)
          HotMouse.Properties.Resources.resourceMan = new ResourceManager("HotMouse.Properties.Resources", typeof (HotMouse.Properties.Resources).Assembly);
        return HotMouse.Properties.Resources.resourceMan;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo Culture
    {
      get
      {
        return HotMouse.Properties.Resources.resourceCulture;
      }
      set
      {
        HotMouse.Properties.Resources.resourceCulture = value;
      }
    }
  }
}
