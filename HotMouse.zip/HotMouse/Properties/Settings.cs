﻿// Decompiled with JetBrains decompiler
// Type: HotMouse.Properties.Settings
// Assembly: HotMouse, Version=0.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: BCDF7B6D-2DF3-46E7-87F7-42EECC13BAFB
// Assembly location: C:\Users\d82mc\AppData\Local\Apps\2.0\JOHL5TOD.DEP\43HDHM9P.HR1\hotm..tion_a6765aedf8daf2cc_0002.0003_8a45d257b7895c72\HotMouse.exe

using System.CodeDom.Compiler;
using System.Configuration;
using System.Runtime.CompilerServices;

namespace HotMouse.Properties
{
  [CompilerGenerated]
  [GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "15.8.0.0")]
  internal sealed class Settings : ApplicationSettingsBase
  {
    private static Settings defaultInstance = (Settings) SettingsBase.Synchronized((SettingsBase) new Settings());

    public static Settings Default
    {
      get
      {
        Settings defaultInstance = Settings.defaultInstance;
        return defaultInstance;
      }
    }
  }
}
