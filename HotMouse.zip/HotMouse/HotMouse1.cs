﻿// Decompiled with JetBrains decompiler
// Type: HotMouse.HotMouse1
// Assembly: HotMouse, Version=0.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: BCDF7B6D-2DF3-46E7-87F7-42EECC13BAFB
// Assembly location: C:\Users\d82mc\AppData\Local\Apps\2.0\JOHL5TOD.DEP\43HDHM9P.HR1\hotm..tion_a6765aedf8daf2cc_0002.0003_8a45d257b7895c72\HotMouse.exe

using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Runtime.InteropServices;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;

namespace HotMouse
{
  public class HotMouse1 : Window, IComponentConnector
  {
    public static string ammend = "     ";
    public static string keystring = "        ";
    public static string twokeystring = "  ";
    public static string threekeystring = "   ";
    private static Point returnpos = new Point();
    private static Timer wait = new Timer();
    private static Timer stopper = new Timer();
    private string[,] array2D = new string[10, 3]
    {
      {
        "1",
        "2",
        "3"
      },
      {
        "4",
        "5",
        "6"
      },
      {
        "7",
        "8",
        "9"
      },
      {
        "10",
        "11",
        "12"
      },
      {
        "13",
        "14",
        "15"
      },
      {
        "16",
        "17",
        "18"
      },
      {
        "19",
        "20",
        "21"
      },
      {
        "22",
        "23",
        "24"
      },
      {
        "25",
        "26",
        "27"
      },
      {
        "28",
        "29",
        "30"
      }
    };
    private int _row = 0;
    private int charmode = 0;
    public static int row1_x;
    public static int row1_y;
    public static int row2_x;
    public static int row2_y;
    public static int row3_x;
    public static int row3_y;
    public static int row4_x;
    public static int row4_y;
    public static int row5_x;
    public static int row5_y;
    public static int row6_x;
    public static int row6_y;
    public static int row7_x;
    public static int row7_y;
    public static int row8_x;
    public static int row8_y;
    public static int row9_x;
    public static int row9_y;
    public static int row0_x;
    public static int row0_y;
    public static Point pt1;
    public static Point pt2;
    public static Point pt3;
    public static Point pt4;
    public static Point pt5;
    public static Point pt6;
    public static Point pt7;
    public static Point pt8;
    public static Point pt9;
    public static Point pt0;
    public static int x;
    public static int y;
    public static int rx;
    public static int ry;
    public static string _x;
    public static string _y;
    public static string _rx;
    public static string _ry;
    public string[] stringArray1;
    public string[] stringArray2;
    public string[] stringArray3;
    public string[] stringArray4;
    public string[] stringArray5;
    public string[] stringArray6;
    public string[] stringArray7;
    public string[] stringArray8;
    public string[] stringArray9;
    public string[] stringArray0;
    public static string onekey;
    private const int MOUSEEVENTF_LEFTDOWN = 2;
    private const int MOUSEEVENTF_LEFTUP = 4;
    private Listener _listener;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal HotMouse1 HotMouse;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal Button rowup_btn;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal Button keycap_btn;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal Button clearrow_btn;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal Button rowdown_btn;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal Button mousecap_btn;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal Button charmodebtn;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal TextBox textBox;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal TextBox textBox1;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal TextBox textBox2;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal TextBox textBox3;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal TextBox textBox4;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal TextBox textBox5;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal TextBox textBox6;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal TextBox textBox7;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal TextBox textBox8;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal TextBox textBox9;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal TextBox textBox10;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal TextBox textBox11;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal TextBox textBox12;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal TextBox textBox13;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal TextBox textBox14;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal TextBox textBox15;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal TextBox textBox16;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal TextBox textBox17;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal TextBox textBox18;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal TextBox textBox19;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal TextBox textBox20;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal TextBox textBox21;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal TextBox textBox22;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal TextBox textBox23;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal TextBox textBox24;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal TextBox textBox25;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal TextBox textBox26;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal TextBox textBox27;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal TextBox textBox28;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal TextBox textBox29;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal TextBox textBox30;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal Label label;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal Label label1;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal Label label2;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal Label label3;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal Button button;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal Button button1;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal Button button2;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal Button button3;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal Button button4;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal Button button5;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal Button button6;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal Button button7;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal Button button8;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal Button button9;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal Button save_btn;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal Button load_btn;
    [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    internal TextBlock textBlock;
    private bool _contentLoaded;

    public HotMouse1()
    {
      this.InitializeComponent();
      this.row = 1;
    }

    private void button_Click(object sender, RoutedEventArgs e)
    {
      if (this.button.Content.ToString() == "OFF")
      {
        this.button.Content = (object) "ON";
        this.button.Background = (Brush) Brushes.Lime;
        this.button.Foreground = (Brush) Brushes.Black;
      }
      else
      {
        this.button.Content = (object) "OFF";
        this.button.Background = (Brush) Brushes.Black;
        this.button.Foreground = (Brush) Brushes.Lime;
      }
    }

    private void button1_Click(object sender, RoutedEventArgs e)
    {
      if (this.button1.Content.ToString() == "OFF")
      {
        this.button1.Content = (object) "ON";
        this.button1.Background = (Brush) Brushes.Lime;
        this.button1.Foreground = (Brush) Brushes.Black;
      }
      else
      {
        this.button1.Content = (object) "OFF";
        this.button1.Background = (Brush) Brushes.Black;
        this.button1.Foreground = (Brush) Brushes.Lime;
      }
    }

    private void button2_Click(object sender, RoutedEventArgs e)
    {
      if (this.button2.Content.ToString() == "OFF")
      {
        this.button2.Content = (object) "ON";
        this.button2.Background = (Brush) Brushes.Lime;
        this.button2.Foreground = (Brush) Brushes.Black;
      }
      else
      {
        this.button2.Content = (object) "OFF";
        this.button2.Background = (Brush) Brushes.Black;
        this.button2.Foreground = (Brush) Brushes.Lime;
      }
    }

    private void button3_Click(object sender, RoutedEventArgs e)
    {
      if (this.button3.Content.ToString() == "OFF")
      {
        this.button3.Content = (object) "ON";
        this.button3.Background = (Brush) Brushes.Lime;
        this.button3.Foreground = (Brush) Brushes.Black;
      }
      else
      {
        this.button3.Content = (object) "OFF";
        this.button3.Background = (Brush) Brushes.Black;
        this.button3.Foreground = (Brush) Brushes.Lime;
      }
    }

    private void button4_Click(object sender, RoutedEventArgs e)
    {
      if (this.button4.Content.ToString() == "OFF")
      {
        this.button4.Content = (object) "ON";
        this.button4.Background = (Brush) Brushes.Lime;
        this.button4.Foreground = (Brush) Brushes.Black;
      }
      else
      {
        this.button4.Content = (object) "OFF";
        this.button4.Background = (Brush) Brushes.Black;
        this.button4.Foreground = (Brush) Brushes.Lime;
      }
    }

    private void button5_Click(object sender, RoutedEventArgs e)
    {
      if (this.button5.Content.ToString() == "OFF")
      {
        this.button5.Content = (object) "ON";
        this.button5.Background = (Brush) Brushes.Lime;
        this.button5.Foreground = (Brush) Brushes.Black;
      }
      else
      {
        this.button5.Content = (object) "OFF";
        this.button5.Background = (Brush) Brushes.Black;
        this.button5.Foreground = (Brush) Brushes.Lime;
      }
    }

    private void button6_Click(object sender, RoutedEventArgs e)
    {
      if (this.button6.Content.ToString() == "OFF")
      {
        this.button6.Content = (object) "ON";
        this.button6.Background = (Brush) Brushes.Lime;
        this.button6.Foreground = (Brush) Brushes.Black;
      }
      else
      {
        this.button6.Content = (object) "OFF";
        this.button6.Background = (Brush) Brushes.Black;
        this.button6.Foreground = (Brush) Brushes.Lime;
      }
    }

    private void button7_Click(object sender, RoutedEventArgs e)
    {
      if (this.button7.Content.ToString() == "OFF")
      {
        this.button7.Content = (object) "ON";
        this.button7.Background = (Brush) Brushes.Lime;
        this.button7.Foreground = (Brush) Brushes.Black;
      }
      else
      {
        this.button7.Content = (object) "OFF";
        this.button7.Background = (Brush) Brushes.Black;
        this.button7.Foreground = (Brush) Brushes.Lime;
      }
    }

    private void button8_Click(object sender, RoutedEventArgs e)
    {
      if (this.button8.Content.ToString() == "OFF")
      {
        this.button8.Content = (object) "ON";
        this.button8.Background = (Brush) Brushes.Lime;
        this.button8.Foreground = (Brush) Brushes.Black;
      }
      else
      {
        this.button8.Content = (object) "OFF";
        this.button8.Background = (Brush) Brushes.Black;
        this.button8.Foreground = (Brush) Brushes.Lime;
      }
    }

    private void button9_Click(object sender, RoutedEventArgs e)
    {
      if (this.button9.Content.ToString() == "OFF")
      {
        this.button9.Content = (object) "ON";
        this.button9.Background = (Brush) Brushes.Lime;
        this.button9.Foreground = (Brush) Brushes.Black;
      }
      else
      {
        this.button9.Content = (object) "OFF";
        this.button9.Background = (Brush) Brushes.Black;
        this.button9.Foreground = (Brush) Brushes.Lime;
      }
    }

    private void charmodebtn_Click(object sender, RoutedEventArgs e)
    {
      switch (this.charmode)
      {
        case 0:
          this.charmode = 1;
          this.label3.Content = (object) "DOUBLE KEY";
          this.charmodebtn.Content = (object) "Use 3 Keys";
          this.keycap_btn.Content = (object) "Capture Keys";
          break;
        case 1:
          this.charmode = 2;
          this.label3.Content = (object) "TRIPLE KEY";
          this.charmodebtn.Content = (object) "Use 1 Key";
          this.keycap_btn.Content = (object) "Capture Keys";
          break;
        case 2:
          this.charmode = 0;
          this.label3.Content = (object) "SINGLE KEY";
          this.charmodebtn.Content = (object) "Use 2 Keys";
          this.keycap_btn.Content = (object) "Capture Key";
          break;
      }
    }

    public static Point GetMousePosition()
    {
      HotMouse1.Win32Point pt = new HotMouse1.Win32Point();
      HotMouse1.GetCursorPos(ref pt);
      return new Point((double) pt.X, (double) pt.Y);
    }

    [DllImport("user32.dll")]
    private static extern bool SetCursorPos(int X, int Y);

    [DllImport("user32.dll")]
    private static extern void mouse_event(
      int dwFlags,
      int dx,
      int dy,
      int cButtons,
      int dwExtraInfo);

    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    internal static extern bool GetCursorPos(ref HotMouse1.Win32Point pt);

    private void keycap_btn_Click(object sender, RoutedEventArgs e)
    {
      switch (this._row)
      {
        case 1:
          this.textBox2.Text = this.textBox.Text;
          break;
        case 2:
          this.textBox5.Text = this.textBox.Text;
          break;
        case 3:
          this.textBox8.Text = this.textBox.Text;
          break;
        case 4:
          this.textBox11.Text = this.textBox.Text;
          break;
        case 5:
          this.textBox14.Text = this.textBox.Text;
          break;
        case 6:
          this.textBox17.Text = this.textBox.Text;
          break;
        case 7:
          this.textBox20.Text = this.textBox.Text;
          break;
        case 8:
          this.textBox23.Text = this.textBox.Text;
          break;
        case 9:
          this.textBox26.Text = this.textBox.Text;
          break;
        case 10:
          this.textBox29.Text = this.textBox.Text;
          break;
      }
    }

    private static void OnTimedEvent(object source, ElapsedEventArgs e)
    {
      HotMouse1.GetMousePosition();
      if (HotMouse1.returnpos.X >= (double) (HotMouse1.x - 15) && HotMouse1.returnpos.X <= (double) (HotMouse1.x + 15) && HotMouse1.returnpos.Y >= (double) (HotMouse1.y - 15) && HotMouse1.returnpos.Y <= (double) (HotMouse1.y + 15))
      {
        HotMouse1.rx = int.Parse(HotMouse1._rx);
        HotMouse1.ry = int.Parse(HotMouse1._ry);
        HotMouse1.SetCursorPos(HotMouse1.rx, HotMouse1.ry);
        HotMouse1.wait.Stop();
        HotMouse1.wait.Enabled = false;
      }
      else
      {
        HotMouse1.wait.Stop();
        HotMouse1.wait.Enabled = false;
      }
    }

    private static void OnStopperEvent(object source, ElapsedEventArgs e)
    {
      HotMouse1.wait.Stop();
    }

    private void rowdown_btn_Click(object sender, RoutedEventArgs e)
    {
      if (this.row != 10)
      {
        ++this.row;
        Console.WriteLine("Selected row " + (object) this.row);
      }
      else
      {
        this.row -= 9;
        Console.WriteLine("Selected row " + (object) this.row);
      }
    }

    private void rowup_btn_Click(object sender, RoutedEventArgs e)
    {
      if (this.row != 1)
      {
        --this.row;
        Console.WriteLine("Selected row " + (object) this.row);
      }
      else
      {
        this.row += 9;
        Console.WriteLine("Selected row " + (object) this.row);
      }
    }

    private void clearrow_btn_Click(object sender, RoutedEventArgs e)
    {
      switch (this._row)
      {
        case 1:
          this.textBox1.Text = "0,0";
          this.textBox2.Text = " ";
          this.textBox3.Text = (string) null;
          break;
        case 2:
          this.textBox4.Text = "0,0";
          this.textBox5.Text = " ";
          this.textBox6.Text = (string) null;
          break;
        case 3:
          this.textBox7.Text = "0,0";
          this.textBox8.Text = " ";
          this.textBox9.Text = (string) null;
          break;
        case 4:
          this.textBox10.Text = "0,0";
          this.textBox11.Text = (string) null;
          this.textBox12.Text = (string) null;
          break;
        case 5:
          this.textBox13.Text = "0,0";
          this.textBox14.Text = " ";
          this.textBox15.Text = (string) null;
          break;
        case 6:
          this.textBox16.Text = "0,0";
          this.textBox17.Text = " ";
          this.textBox18.Text = (string) null;
          break;
        case 7:
          this.textBox19.Text = "0,0";
          this.textBox20.Text = (string) null;
          this.textBox21.Text = (string) null;
          break;
        case 8:
          this.textBox22.Text = "0,0";
          this.textBox23.Text = " ";
          this.textBox24.Text = (string) null;
          break;
        case 9:
          this.textBox25.Text = "0,0";
          this.textBox26.Text = " ";
          this.textBox27.Text = (string) null;
          break;
        case 10:
          this.textBox28.Text = "0,0";
          this.textBox29.Text = " ";
          this.textBox30.Text = (string) null;
          break;
      }
    }

    private void mousecap_btn_LostMouseCapture(object sender, MouseEventArgs e)
    {
      HotMouse1._x = HotMouse1.GetMousePosition().X.ToString();
      HotMouse1._y = HotMouse1.GetMousePosition().Y.ToString();
      string[] strArray = new string[2]
      {
        HotMouse1._x,
        HotMouse1._y
      };
      string separator = ", ";
      switch (this._row)
      {
        case 1:
          this.textBox1.Text = string.Join(separator, strArray);
          break;
        case 2:
          this.textBox4.Text = string.Join(separator, strArray);
          break;
        case 3:
          this.textBox7.Text = string.Join(separator, strArray);
          break;
        case 4:
          this.textBox10.Text = string.Join(separator, strArray);
          break;
        case 5:
          this.textBox13.Text = string.Join(separator, strArray);
          break;
        case 6:
          this.textBox16.Text = string.Join(separator, strArray);
          break;
        case 7:
          this.textBox19.Text = string.Join(separator, strArray);
          break;
        case 8:
          this.textBox22.Text = string.Join(separator, strArray);
          break;
        case 9:
          this.textBox25.Text = string.Join(separator, strArray);
          break;
        case 10:
          this.textBox28.Text = string.Join(separator, strArray);
          break;
      }
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      this._listener = new Listener();
      this._listener.OnKeyPressed += new EventHandler<KeyPressedArgs>(this._listener_OnKeyPressed);
      this._listener.HookKeyboard();
    }

    private void _listener_OnKeyPressed(object sender, KeyPressedArgs e)
    {
      HotMouse1.keystring += e.KeyPressed.ToString();
      HotMouse1.ammend = HotMouse1.keystring.Replace("Oem", "").Replace("Space", "_").Replace("Left", "").Replace("Right", "").Replace("D1", "1").Replace("D2", "2").Replace("D3", "3").Replace("D4", "4").Replace("D5", "5").Replace("D6", "6").Replace("D7", "7").Replace("D8", "8").Replace("D9", "9").Replace("D0", "0").Replace("Question", "/").Replace("Comma", ",").Replace("Period", ".").Replace("Minus", "-").Replace("Plus", "=").Replace("OpenBrackets", "[").Replace("Quotes", "'").Replace("Shift", "^").Replace("Ctrl", "#").Replace("Alt", "*").Replace("Tab", ">");
      HotMouse1.onekey = HotMouse1.ammend.Substring(HotMouse1.ammend.Length - 1);
      HotMouse1.twokeystring = HotMouse1.ammend.Substring(HotMouse1.ammend.Length - 2);
      HotMouse1.threekeystring = HotMouse1.ammend.Substring(HotMouse1.ammend.Length - 3);
      if (HotMouse1.keystring.Length > 700)
        HotMouse1.keystring = HotMouse1.keystring.Substring(HotMouse1.keystring.Length - 700);
      this.textBlock.Text = HotMouse1.ammend.Length <= 57 ? HotMouse1.ammend : HotMouse1.ammend.Substring(HotMouse1.ammend.Length - 56);
      HotMouse1._rx = HotMouse1.GetMousePosition().X.ToString();
      HotMouse1._ry = HotMouse1.GetMousePosition().Y.ToString();
      this.stringArray1 = this.textBox1.Text.Split(',');
      this.stringArray2 = this.textBox4.Text.Split(',');
      this.stringArray3 = this.textBox7.Text.Split(',');
      this.stringArray4 = this.textBox10.Text.Split(',');
      this.stringArray5 = this.textBox13.Text.Split(',');
      this.stringArray6 = this.textBox16.Text.Split(',');
      this.stringArray7 = this.textBox19.Text.Split(',');
      this.stringArray8 = this.textBox22.Text.Split(',');
      this.stringArray9 = this.textBox25.Text.Split(',');
      this.stringArray0 = this.textBox28.Text.Split(',');
      if (this.stringArray1 != null)
      {
        HotMouse1.row1_x = int.Parse(((IEnumerable<string>) this.stringArray1).First<string>());
        HotMouse1.row1_y = int.Parse(((IEnumerable<string>) this.stringArray1).Last<string>());
      }
      if (this.stringArray2 != null)
      {
        HotMouse1.row2_x = int.Parse(((IEnumerable<string>) this.stringArray2).First<string>());
        HotMouse1.row2_y = int.Parse(((IEnumerable<string>) this.stringArray2).Last<string>());
      }
      if (this.stringArray3 != null)
      {
        HotMouse1.row3_x = int.Parse(((IEnumerable<string>) this.stringArray3).First<string>());
        HotMouse1.row3_y = int.Parse(((IEnumerable<string>) this.stringArray3).Last<string>());
      }
      if (this.stringArray4 != null)
      {
        HotMouse1.row4_x = int.Parse(((IEnumerable<string>) this.stringArray4).First<string>());
        HotMouse1.row4_y = int.Parse(((IEnumerable<string>) this.stringArray4).Last<string>());
      }
      if (this.stringArray5 != null)
      {
        HotMouse1.row5_x = int.Parse(((IEnumerable<string>) this.stringArray5).First<string>());
        HotMouse1.row5_y = int.Parse(((IEnumerable<string>) this.stringArray5).Last<string>());
      }
      if (this.stringArray6 != null)
      {
        HotMouse1.row6_x = int.Parse(((IEnumerable<string>) this.stringArray6).First<string>());
        HotMouse1.row6_y = int.Parse(((IEnumerable<string>) this.stringArray6).Last<string>());
      }
      if (this.stringArray7 != null)
      {
        HotMouse1.row7_x = int.Parse(((IEnumerable<string>) this.stringArray7).First<string>());
        HotMouse1.row7_y = int.Parse(((IEnumerable<string>) this.stringArray7).Last<string>());
      }
      if (this.stringArray8 != null)
      {
        HotMouse1.row8_x = int.Parse(((IEnumerable<string>) this.stringArray8).First<string>());
        HotMouse1.row8_y = int.Parse(((IEnumerable<string>) this.stringArray8).Last<string>());
      }
      if (this.stringArray9 != null)
      {
        HotMouse1.row9_x = int.Parse(((IEnumerable<string>) this.stringArray9).First<string>());
        HotMouse1.row9_y = int.Parse(((IEnumerable<string>) this.stringArray9).Last<string>());
      }
      if (this.stringArray9 != null)
      {
        HotMouse1.row0_x = int.Parse(((IEnumerable<string>) this.stringArray0).First<string>());
        HotMouse1.row0_y = int.Parse(((IEnumerable<string>) this.stringArray0).Last<string>());
      }
      switch (this.charmode)
      {
        case 0:
          this.textBox.Text = HotMouse1.onekey;
          if ((HotMouse1.onekey == this.textBox2.Text || HotMouse1.twokeystring == this.textBox2.Text || HotMouse1.threekeystring == this.textBox2.Text) && this.button.Content.ToString() == "ON")
          {
            HotMouse1.wait.Elapsed += new ElapsedEventHandler(HotMouse1.OnTimedEvent);
            HotMouse1.wait.Interval = 1.0;
            HotMouse1.stopper.Elapsed += new ElapsedEventHandler(HotMouse1.OnStopperEvent);
            HotMouse1.stopper.Interval = 2.0;
            HotMouse1.SetCursorPos(HotMouse1.row1_x, HotMouse1.row1_y);
            HotMouse1.mouse_event(2, HotMouse1.row1_x, HotMouse1.row1_y, 0, 0);
            HotMouse1.mouse_event(4, HotMouse1.row1_x, HotMouse1.row1_y, 0, 0);
            HotMouse1.wait.Enabled = true;
          }
          if (HotMouse1.onekey == this.textBox5.Text && this.button1.Content.ToString() == "ON")
          {
            HotMouse1.wait.Elapsed += new ElapsedEventHandler(HotMouse1.OnTimedEvent);
            HotMouse1.wait.Interval = 1.0;
            HotMouse1.stopper.Elapsed += new ElapsedEventHandler(HotMouse1.OnStopperEvent);
            HotMouse1.stopper.Interval = 2.0;
            HotMouse1.SetCursorPos(HotMouse1.row2_x, HotMouse1.row2_y);
            HotMouse1.mouse_event(2, HotMouse1.row2_x, HotMouse1.row2_y, 0, 0);
            HotMouse1.mouse_event(4, HotMouse1.row2_x, HotMouse1.row2_y, 0, 0);
            HotMouse1.wait.Enabled = true;
          }
          if (HotMouse1.onekey == this.textBox8.Text && this.button2.Content.ToString() == "ON")
          {
            HotMouse1.wait.Elapsed += new ElapsedEventHandler(HotMouse1.OnTimedEvent);
            HotMouse1.wait.Interval = 1.0;
            HotMouse1.stopper.Elapsed += new ElapsedEventHandler(HotMouse1.OnStopperEvent);
            HotMouse1.stopper.Interval = 2.0;
            HotMouse1.SetCursorPos(HotMouse1.row3_x, HotMouse1.row3_y);
            HotMouse1.mouse_event(2, HotMouse1.row3_x, HotMouse1.row3_y, 0, 0);
            HotMouse1.mouse_event(4, HotMouse1.row3_x, HotMouse1.row3_y, 0, 0);
            HotMouse1.wait.Enabled = true;
          }
          if (HotMouse1.onekey == this.textBox11.Text && this.button3.Content.ToString() == "ON")
          {
            HotMouse1.wait.Elapsed += new ElapsedEventHandler(HotMouse1.OnTimedEvent);
            HotMouse1.wait.Interval = 1.0;
            HotMouse1.stopper.Elapsed += new ElapsedEventHandler(HotMouse1.OnStopperEvent);
            HotMouse1.stopper.Interval = 2.0;
            HotMouse1.SetCursorPos(HotMouse1.row4_x, HotMouse1.row4_y);
            HotMouse1.mouse_event(2, HotMouse1.row4_x, HotMouse1.row4_y, 0, 0);
            HotMouse1.mouse_event(4, HotMouse1.row4_x, HotMouse1.row4_y, 0, 0);
            HotMouse1.wait.Enabled = true;
          }
          if (HotMouse1.onekey == this.textBox14.Text && this.button4.Content.ToString() == "ON")
          {
            HotMouse1.wait.Elapsed += new ElapsedEventHandler(HotMouse1.OnTimedEvent);
            HotMouse1.wait.Interval = 1.0;
            HotMouse1.stopper.Elapsed += new ElapsedEventHandler(HotMouse1.OnStopperEvent);
            HotMouse1.stopper.Interval = 2.0;
            HotMouse1.SetCursorPos(HotMouse1.row5_x, HotMouse1.row5_y);
            HotMouse1.mouse_event(2, HotMouse1.row5_x, HotMouse1.row5_y, 0, 0);
            HotMouse1.mouse_event(4, HotMouse1.row5_x, HotMouse1.row5_y, 0, 0);
            HotMouse1.wait.Enabled = true;
          }
          if (HotMouse1.onekey == this.textBox17.Text && this.button5.Content.ToString() == "ON")
          {
            HotMouse1.wait.Elapsed += new ElapsedEventHandler(HotMouse1.OnTimedEvent);
            HotMouse1.wait.Interval = 1.0;
            HotMouse1.stopper.Elapsed += new ElapsedEventHandler(HotMouse1.OnStopperEvent);
            HotMouse1.stopper.Interval = 2.0;
            HotMouse1.SetCursorPos(HotMouse1.row6_x, HotMouse1.row6_y);
            HotMouse1.mouse_event(2, HotMouse1.row6_x, HotMouse1.row6_y, 0, 0);
            HotMouse1.mouse_event(4, HotMouse1.row6_x, HotMouse1.row6_y, 0, 0);
            HotMouse1.wait.Enabled = true;
          }
          if (HotMouse1.onekey == this.textBox20.Text && this.button6.Content.ToString() == "ON")
          {
            HotMouse1.wait.Elapsed += new ElapsedEventHandler(HotMouse1.OnTimedEvent);
            HotMouse1.wait.Interval = 1.0;
            HotMouse1.stopper.Elapsed += new ElapsedEventHandler(HotMouse1.OnStopperEvent);
            HotMouse1.stopper.Interval = 2.0;
            HotMouse1.SetCursorPos(HotMouse1.row7_x, HotMouse1.row7_y);
            HotMouse1.mouse_event(2, HotMouse1.row7_x, HotMouse1.row7_y, 0, 0);
            HotMouse1.mouse_event(4, HotMouse1.row7_x, HotMouse1.row7_y, 0, 0);
            HotMouse1.wait.Enabled = true;
          }
          if (HotMouse1.onekey == this.textBox23.Text && this.button7.Content.ToString() == "ON")
          {
            HotMouse1.wait.Elapsed += new ElapsedEventHandler(HotMouse1.OnTimedEvent);
            HotMouse1.wait.Interval = 1.0;
            HotMouse1.stopper.Elapsed += new ElapsedEventHandler(HotMouse1.OnStopperEvent);
            HotMouse1.stopper.Interval = 2.0;
            HotMouse1.SetCursorPos(HotMouse1.row8_x, HotMouse1.row8_y);
            HotMouse1.mouse_event(2, HotMouse1.row8_x, HotMouse1.row8_y, 0, 0);
            HotMouse1.mouse_event(4, HotMouse1.row8_x, HotMouse1.row8_y, 0, 0);
            HotMouse1.wait.Enabled = true;
          }
          if (HotMouse1.onekey == this.textBox26.Text && this.button8.Content.ToString() == "ON")
          {
            HotMouse1.wait.Elapsed += new ElapsedEventHandler(HotMouse1.OnTimedEvent);
            HotMouse1.wait.Interval = 1.0;
            HotMouse1.stopper.Elapsed += new ElapsedEventHandler(HotMouse1.OnStopperEvent);
            HotMouse1.stopper.Interval = 2.0;
            HotMouse1.SetCursorPos(HotMouse1.row9_x, HotMouse1.row9_y);
            HotMouse1.mouse_event(2, HotMouse1.row9_x, HotMouse1.row9_y, 0, 0);
            HotMouse1.mouse_event(4, HotMouse1.row9_x, HotMouse1.row9_y, 0, 0);
            HotMouse1.wait.Enabled = true;
          }
          if (!(HotMouse1.onekey == this.textBox29.Text) || !(this.button9.Content.ToString() == "ON"))
            break;
          HotMouse1.wait.Elapsed += new ElapsedEventHandler(HotMouse1.OnTimedEvent);
          HotMouse1.wait.Interval = 1.0;
          HotMouse1.stopper.Elapsed += new ElapsedEventHandler(HotMouse1.OnStopperEvent);
          HotMouse1.stopper.Interval = 2.0;
          HotMouse1.SetCursorPos(HotMouse1.row0_x, HotMouse1.row0_y);
          HotMouse1.mouse_event(2, HotMouse1.row0_x, HotMouse1.row0_y, 0, 0);
          HotMouse1.mouse_event(4, HotMouse1.row0_x, HotMouse1.row0_y, 0, 0);
          HotMouse1.wait.Enabled = true;
          break;
        case 1:
          this.textBox.Text = HotMouse1.twokeystring;
          if (HotMouse1.twokeystring == this.textBox2.Text && this.button.Content.ToString() == "ON")
          {
            HotMouse1.wait.Elapsed += new ElapsedEventHandler(HotMouse1.OnTimedEvent);
            HotMouse1.wait.Interval = 1.0;
            HotMouse1.stopper.Elapsed += new ElapsedEventHandler(HotMouse1.OnStopperEvent);
            HotMouse1.stopper.Interval = 2.0;
            HotMouse1.SetCursorPos(HotMouse1.row1_x, HotMouse1.row1_y);
            HotMouse1.mouse_event(2, HotMouse1.row1_x, HotMouse1.row1_y, 0, 0);
            HotMouse1.mouse_event(4, HotMouse1.row1_x, HotMouse1.row1_y, 0, 0);
            HotMouse1.wait.Enabled = true;
          }
          if (HotMouse1.twokeystring == this.textBox5.Text && this.button1.Content.ToString() == "ON")
          {
            HotMouse1.wait.Elapsed += new ElapsedEventHandler(HotMouse1.OnTimedEvent);
            HotMouse1.wait.Interval = 1.0;
            HotMouse1.stopper.Elapsed += new ElapsedEventHandler(HotMouse1.OnStopperEvent);
            HotMouse1.stopper.Interval = 2.0;
            HotMouse1.SetCursorPos(HotMouse1.row2_x, HotMouse1.row2_y);
            HotMouse1.mouse_event(2, HotMouse1.row2_x, HotMouse1.row2_y, 0, 0);
            HotMouse1.mouse_event(4, HotMouse1.row2_x, HotMouse1.row2_y, 0, 0);
            HotMouse1.wait.Enabled = true;
          }
          if (HotMouse1.twokeystring == this.textBox8.Text && this.button2.Content.ToString() == "ON")
          {
            HotMouse1.wait.Elapsed += new ElapsedEventHandler(HotMouse1.OnTimedEvent);
            HotMouse1.wait.Interval = 1.0;
            HotMouse1.stopper.Elapsed += new ElapsedEventHandler(HotMouse1.OnStopperEvent);
            HotMouse1.stopper.Interval = 2.0;
            HotMouse1.SetCursorPos(HotMouse1.row3_x, HotMouse1.row3_y);
            HotMouse1.mouse_event(2, HotMouse1.row3_x, HotMouse1.row3_y, 0, 0);
            HotMouse1.mouse_event(4, HotMouse1.row3_x, HotMouse1.row3_y, 0, 0);
            HotMouse1.wait.Enabled = true;
          }
          if (HotMouse1.twokeystring == this.textBox11.Text && this.button3.Content.ToString() == "ON")
          {
            HotMouse1.wait.Elapsed += new ElapsedEventHandler(HotMouse1.OnTimedEvent);
            HotMouse1.wait.Interval = 1.0;
            HotMouse1.stopper.Elapsed += new ElapsedEventHandler(HotMouse1.OnStopperEvent);
            HotMouse1.stopper.Interval = 2.0;
            HotMouse1.SetCursorPos(HotMouse1.row4_x, HotMouse1.row4_x);
            HotMouse1.mouse_event(2, HotMouse1.row4_x, HotMouse1.row4_y, 0, 0);
            HotMouse1.mouse_event(4, HotMouse1.row4_x, HotMouse1.row4_y, 0, 0);
            HotMouse1.wait.Enabled = true;
          }
          if (HotMouse1.twokeystring == this.textBox14.Text && this.button4.Content.ToString() == "ON")
          {
            HotMouse1.wait.Elapsed += new ElapsedEventHandler(HotMouse1.OnTimedEvent);
            HotMouse1.wait.Interval = 1.0;
            HotMouse1.stopper.Elapsed += new ElapsedEventHandler(HotMouse1.OnStopperEvent);
            HotMouse1.stopper.Interval = 2.0;
            HotMouse1.SetCursorPos(HotMouse1.row5_x, HotMouse1.row5_y);
            HotMouse1.mouse_event(2, HotMouse1.row5_x, HotMouse1.row5_y, 0, 0);
            HotMouse1.mouse_event(4, HotMouse1.row5_x, HotMouse1.row5_y, 0, 0);
            HotMouse1.wait.Enabled = true;
          }
          if (HotMouse1.twokeystring == this.textBox17.Text && this.button5.Content.ToString() == "ON")
          {
            HotMouse1.wait.Elapsed += new ElapsedEventHandler(HotMouse1.OnTimedEvent);
            HotMouse1.wait.Interval = 1.0;
            HotMouse1.stopper.Elapsed += new ElapsedEventHandler(HotMouse1.OnStopperEvent);
            HotMouse1.stopper.Interval = 2.0;
            HotMouse1.SetCursorPos(HotMouse1.row6_x, HotMouse1.row6_y);
            HotMouse1.mouse_event(2, HotMouse1.row6_x, HotMouse1.row6_y, 0, 0);
            HotMouse1.mouse_event(4, HotMouse1.row6_x, HotMouse1.row6_y, 0, 0);
            HotMouse1.wait.Enabled = true;
          }
          if (HotMouse1.twokeystring == this.textBox20.Text && this.button6.Content.ToString() == "ON")
          {
            HotMouse1.wait.Elapsed += new ElapsedEventHandler(HotMouse1.OnTimedEvent);
            HotMouse1.wait.Interval = 1.0;
            HotMouse1.stopper.Elapsed += new ElapsedEventHandler(HotMouse1.OnStopperEvent);
            HotMouse1.stopper.Interval = 2.0;
            HotMouse1.SetCursorPos(HotMouse1.row7_x, HotMouse1.row7_y);
            HotMouse1.mouse_event(2, HotMouse1.row7_x, HotMouse1.row7_y, 0, 0);
            HotMouse1.mouse_event(4, HotMouse1.row7_x, HotMouse1.row7_y, 0, 0);
            HotMouse1.wait.Enabled = true;
          }
          if (HotMouse1.twokeystring == this.textBox23.Text && this.button7.Content.ToString() == "ON")
          {
            HotMouse1.wait.Elapsed += new ElapsedEventHandler(HotMouse1.OnTimedEvent);
            HotMouse1.wait.Interval = 1.0;
            HotMouse1.stopper.Elapsed += new ElapsedEventHandler(HotMouse1.OnStopperEvent);
            HotMouse1.stopper.Interval = 2.0;
            HotMouse1.SetCursorPos(HotMouse1.row8_x, HotMouse1.row8_y);
            HotMouse1.mouse_event(2, HotMouse1.row8_x, HotMouse1.row8_y, 0, 0);
            HotMouse1.mouse_event(4, HotMouse1.row8_x, HotMouse1.row8_y, 0, 0);
            HotMouse1.wait.Enabled = true;
          }
          if (HotMouse1.twokeystring == this.textBox26.Text && this.button8.Content.ToString() == "ON")
          {
            HotMouse1.wait.Elapsed += new ElapsedEventHandler(HotMouse1.OnTimedEvent);
            HotMouse1.wait.Interval = 1.0;
            HotMouse1.stopper.Elapsed += new ElapsedEventHandler(HotMouse1.OnStopperEvent);
            HotMouse1.stopper.Interval = 2.0;
            HotMouse1.SetCursorPos(HotMouse1.row9_x, HotMouse1.row9_y);
            HotMouse1.mouse_event(2, HotMouse1.row9_x, HotMouse1.row9_y, 0, 0);
            HotMouse1.mouse_event(4, HotMouse1.row9_x, HotMouse1.row9_y, 0, 0);
            HotMouse1.wait.Enabled = true;
          }
          if (!(HotMouse1.twokeystring == this.textBox29.Text) || !(this.button9.Content.ToString() == "ON"))
            break;
          HotMouse1.wait.Elapsed += new ElapsedEventHandler(HotMouse1.OnTimedEvent);
          HotMouse1.wait.Interval = 1.0;
          HotMouse1.stopper.Elapsed += new ElapsedEventHandler(HotMouse1.OnStopperEvent);
          HotMouse1.stopper.Interval = 2.0;
          HotMouse1.SetCursorPos(HotMouse1.row0_x, HotMouse1.row0_y);
          HotMouse1.mouse_event(2, HotMouse1.row0_x, HotMouse1.row0_y, 0, 0);
          HotMouse1.mouse_event(4, HotMouse1.row0_x, HotMouse1.row0_y, 0, 0);
          HotMouse1.wait.Enabled = true;
          break;
        case 2:
          this.textBox.Text = HotMouse1.threekeystring;
          if (HotMouse1.threekeystring == this.textBox2.Text && this.button.Content.ToString() == "ON")
          {
            HotMouse1.wait.Elapsed += new ElapsedEventHandler(HotMouse1.OnTimedEvent);
            HotMouse1.wait.Interval = 1.0;
            HotMouse1.stopper.Elapsed += new ElapsedEventHandler(HotMouse1.OnStopperEvent);
            HotMouse1.stopper.Interval = 2.0;
            HotMouse1.SetCursorPos(HotMouse1.row1_x, HotMouse1.row1_y);
            HotMouse1.mouse_event(2, HotMouse1.row1_x, HotMouse1.row1_y, 0, 0);
            HotMouse1.mouse_event(4, HotMouse1.row1_x, HotMouse1.row1_y, 0, 0);
            HotMouse1.wait.Enabled = true;
          }
          if (HotMouse1.threekeystring == this.textBox5.Text && this.button1.Content.ToString() == "ON")
          {
            HotMouse1.wait.Elapsed += new ElapsedEventHandler(HotMouse1.OnTimedEvent);
            HotMouse1.wait.Interval = 1.0;
            HotMouse1.stopper.Elapsed += new ElapsedEventHandler(HotMouse1.OnStopperEvent);
            HotMouse1.stopper.Interval = 2.0;
            HotMouse1.SetCursorPos(HotMouse1.row2_x, HotMouse1.row2_y);
            HotMouse1.mouse_event(2, HotMouse1.row2_x, HotMouse1.row2_y, 0, 0);
            HotMouse1.mouse_event(4, HotMouse1.row2_x, HotMouse1.row2_y, 0, 0);
            HotMouse1.wait.Enabled = true;
          }
          if (HotMouse1.threekeystring == this.textBox8.Text && this.button2.Content.ToString() == "ON")
          {
            HotMouse1.wait.Elapsed += new ElapsedEventHandler(HotMouse1.OnTimedEvent);
            HotMouse1.wait.Interval = 1.0;
            HotMouse1.stopper.Elapsed += new ElapsedEventHandler(HotMouse1.OnStopperEvent);
            HotMouse1.stopper.Interval = 2.0;
            HotMouse1.SetCursorPos(HotMouse1.row3_x, HotMouse1.row3_y);
            HotMouse1.mouse_event(2, HotMouse1.row3_x, HotMouse1.row3_y, 0, 0);
            HotMouse1.mouse_event(4, HotMouse1.row3_x, HotMouse1.row3_y, 0, 0);
            HotMouse1.wait.Enabled = true;
          }
          if (HotMouse1.threekeystring == this.textBox11.Text && this.button3.Content.ToString() == "ON")
          {
            HotMouse1.wait.Elapsed += new ElapsedEventHandler(HotMouse1.OnTimedEvent);
            HotMouse1.wait.Interval = 1.0;
            HotMouse1.stopper.Elapsed += new ElapsedEventHandler(HotMouse1.OnStopperEvent);
            HotMouse1.stopper.Interval = 2.0;
            HotMouse1.SetCursorPos(HotMouse1.row4_x, HotMouse1.row4_y);
            HotMouse1.mouse_event(2, HotMouse1.row4_x, HotMouse1.row4_y, 0, 0);
            HotMouse1.mouse_event(4, HotMouse1.row4_x, HotMouse1.row4_y, 0, 0);
            HotMouse1.wait.Enabled = true;
          }
          if (HotMouse1.threekeystring == this.textBox14.Text && this.button4.Content.ToString() == "ON")
          {
            HotMouse1.wait.Elapsed += new ElapsedEventHandler(HotMouse1.OnTimedEvent);
            HotMouse1.wait.Interval = 1.0;
            HotMouse1.stopper.Elapsed += new ElapsedEventHandler(HotMouse1.OnStopperEvent);
            HotMouse1.stopper.Interval = 2.0;
            HotMouse1.SetCursorPos(HotMouse1.row5_x, HotMouse1.row5_y);
            HotMouse1.mouse_event(2, HotMouse1.row5_x, HotMouse1.row5_y, 0, 0);
            HotMouse1.mouse_event(4, HotMouse1.row5_x, HotMouse1.row5_y, 0, 0);
            HotMouse1.wait.Enabled = true;
          }
          if (HotMouse1.threekeystring == this.textBox17.Text && this.button5.Content.ToString() == "ON")
          {
            HotMouse1.wait.Elapsed += new ElapsedEventHandler(HotMouse1.OnTimedEvent);
            HotMouse1.wait.Interval = 1.0;
            HotMouse1.stopper.Elapsed += new ElapsedEventHandler(HotMouse1.OnStopperEvent);
            HotMouse1.stopper.Interval = 2.0;
            HotMouse1.SetCursorPos(HotMouse1.row6_x, HotMouse1.row6_y);
            HotMouse1.mouse_event(2, HotMouse1.row6_x, HotMouse1.row6_y, 0, 0);
            HotMouse1.mouse_event(4, HotMouse1.row6_x, HotMouse1.row6_y, 0, 0);
            HotMouse1.wait.Enabled = true;
          }
          if (HotMouse1.threekeystring == this.textBox20.Text && this.button6.Content.ToString() == "ON")
          {
            HotMouse1.wait.Elapsed += new ElapsedEventHandler(HotMouse1.OnTimedEvent);
            HotMouse1.wait.Interval = 1.0;
            HotMouse1.stopper.Elapsed += new ElapsedEventHandler(HotMouse1.OnStopperEvent);
            HotMouse1.stopper.Interval = 2.0;
            HotMouse1.SetCursorPos(HotMouse1.row7_x, HotMouse1.row7_y);
            HotMouse1.mouse_event(2, HotMouse1.row7_x, HotMouse1.row7_y, 0, 0);
            HotMouse1.mouse_event(4, HotMouse1.row7_x, HotMouse1.row7_y, 0, 0);
            HotMouse1.wait.Enabled = true;
          }
          if (HotMouse1.threekeystring == this.textBox23.Text && this.button7.Content.ToString() == "ON")
          {
            HotMouse1.wait.Elapsed += new ElapsedEventHandler(HotMouse1.OnTimedEvent);
            HotMouse1.wait.Interval = 1.0;
            HotMouse1.stopper.Elapsed += new ElapsedEventHandler(HotMouse1.OnStopperEvent);
            HotMouse1.stopper.Interval = 2.0;
            HotMouse1.SetCursorPos(HotMouse1.row8_x, HotMouse1.row8_y);
            HotMouse1.mouse_event(2, HotMouse1.row8_x, HotMouse1.row8_y, 0, 0);
            HotMouse1.mouse_event(4, HotMouse1.row8_x, HotMouse1.row8_y, 0, 0);
            HotMouse1.wait.Enabled = true;
          }
          if (HotMouse1.threekeystring == this.textBox26.Text && this.button8.Content.ToString() == "ON")
          {
            HotMouse1.wait.Elapsed += new ElapsedEventHandler(HotMouse1.OnTimedEvent);
            HotMouse1.wait.Interval = 1.0;
            HotMouse1.stopper.Elapsed += new ElapsedEventHandler(HotMouse1.OnStopperEvent);
            HotMouse1.stopper.Interval = 2.0;
            HotMouse1.SetCursorPos(HotMouse1.row9_x, HotMouse1.row9_y);
            HotMouse1.mouse_event(2, HotMouse1.row9_x, HotMouse1.row9_y, 0, 0);
            HotMouse1.mouse_event(4, HotMouse1.row9_x, HotMouse1.row9_y, 0, 0);
            HotMouse1.wait.Enabled = true;
          }
          if (!(HotMouse1.threekeystring == this.textBox29.Text) || !(this.button9.Content.ToString() == "ON"))
            break;
          HotMouse1.wait.Elapsed += new ElapsedEventHandler(HotMouse1.OnTimedEvent);
          HotMouse1.wait.Interval = 1.0;
          HotMouse1.stopper.Elapsed += new ElapsedEventHandler(HotMouse1.OnStopperEvent);
          HotMouse1.stopper.Interval = 2.0;
          HotMouse1.SetCursorPos(HotMouse1.row0_x, HotMouse1.row0_y);
          HotMouse1.mouse_event(2, HotMouse1.row0_x, HotMouse1.row0_y, 0, 0);
          HotMouse1.mouse_event(4, HotMouse1.row0_x, HotMouse1.row0_y, 0, 0);
          HotMouse1.wait.Enabled = true;
          break;
      }
    }

    private void Window_Closing(object sender, CancelEventArgs e)
    {
      this._listener.UnHookKeyboard();
    }

    public int row
    {
      get
      {
        return this._row;
      }
      set
      {
        this._row = value;
        if (this._row != 1)
        {
          this.textBox1.Background = (Brush) Brushes.Black;
          this.textBox2.Background = (Brush) Brushes.Black;
          this.textBox1.Foreground = (Brush) Brushes.Lime;
          this.textBox2.Foreground = (Brush) Brushes.Lime;
          this.textBox1.BorderBrush = (Brush) Brushes.Lime;
          this.textBox2.BorderBrush = (Brush) Brushes.Lime;
        }
        else
        {
          this.textBox1.Background = (Brush) Brushes.Lime;
          this.textBox2.Background = (Brush) Brushes.Lime;
          this.textBox1.Foreground = (Brush) Brushes.Black;
          this.textBox2.Foreground = (Brush) Brushes.Black;
          this.textBox1.BorderBrush = (Brush) Brushes.Black;
          this.textBox2.BorderBrush = (Brush) Brushes.Black;
        }
        if (this._row != 2)
        {
          this.textBox4.Background = (Brush) Brushes.Black;
          this.textBox5.Background = (Brush) Brushes.Black;
          this.textBox4.Foreground = (Brush) Brushes.Lime;
          this.textBox5.Foreground = (Brush) Brushes.Lime;
          this.textBox4.BorderBrush = (Brush) Brushes.Lime;
          this.textBox5.BorderBrush = (Brush) Brushes.Lime;
        }
        else
        {
          this.textBox4.Background = (Brush) Brushes.Lime;
          this.textBox5.Background = (Brush) Brushes.Lime;
          this.textBox4.Foreground = (Brush) Brushes.Black;
          this.textBox5.Foreground = (Brush) Brushes.Black;
          this.textBox4.BorderBrush = (Brush) Brushes.Black;
          this.textBox5.BorderBrush = (Brush) Brushes.Black;
        }
        if (this._row != 3)
        {
          this.textBox7.Background = (Brush) Brushes.Black;
          this.textBox8.Background = (Brush) Brushes.Black;
          this.textBox7.Foreground = (Brush) Brushes.Lime;
          this.textBox8.Foreground = (Brush) Brushes.Lime;
          this.textBox7.BorderBrush = (Brush) Brushes.Lime;
          this.textBox8.BorderBrush = (Brush) Brushes.Lime;
        }
        else
        {
          this.textBox7.Background = (Brush) Brushes.Lime;
          this.textBox8.Background = (Brush) Brushes.Lime;
          this.textBox7.Foreground = (Brush) Brushes.Black;
          this.textBox8.Foreground = (Brush) Brushes.Black;
          this.textBox7.BorderBrush = (Brush) Brushes.Black;
          this.textBox8.BorderBrush = (Brush) Brushes.Black;
        }
        if (this._row != 4)
        {
          this.textBox10.Background = (Brush) Brushes.Black;
          this.textBox11.Background = (Brush) Brushes.Black;
          this.textBox10.Foreground = (Brush) Brushes.Lime;
          this.textBox11.Foreground = (Brush) Brushes.Lime;
          this.textBox10.BorderBrush = (Brush) Brushes.Lime;
          this.textBox11.BorderBrush = (Brush) Brushes.Lime;
        }
        else
        {
          this.textBox10.Background = (Brush) Brushes.Lime;
          this.textBox11.Background = (Brush) Brushes.Lime;
          this.textBox10.Foreground = (Brush) Brushes.Black;
          this.textBox11.Foreground = (Brush) Brushes.Black;
          this.textBox10.BorderBrush = (Brush) Brushes.Black;
          this.textBox11.BorderBrush = (Brush) Brushes.Black;
        }
        if (this._row != 5)
        {
          this.textBox13.Background = (Brush) Brushes.Black;
          this.textBox14.Background = (Brush) Brushes.Black;
          this.textBox13.Foreground = (Brush) Brushes.Lime;
          this.textBox14.Foreground = (Brush) Brushes.Lime;
          this.textBox13.BorderBrush = (Brush) Brushes.Lime;
          this.textBox14.BorderBrush = (Brush) Brushes.Lime;
        }
        else
        {
          this.textBox13.Background = (Brush) Brushes.Lime;
          this.textBox14.Background = (Brush) Brushes.Lime;
          this.textBox13.Foreground = (Brush) Brushes.Black;
          this.textBox14.Foreground = (Brush) Brushes.Black;
          this.textBox13.BorderBrush = (Brush) Brushes.Black;
          this.textBox14.BorderBrush = (Brush) Brushes.Black;
        }
        if (this._row != 6)
        {
          this.textBox16.Background = (Brush) Brushes.Black;
          this.textBox17.Background = (Brush) Brushes.Black;
          this.textBox16.Foreground = (Brush) Brushes.Lime;
          this.textBox17.Foreground = (Brush) Brushes.Lime;
          this.textBox16.BorderBrush = (Brush) Brushes.Lime;
          this.textBox17.BorderBrush = (Brush) Brushes.Lime;
        }
        else
        {
          this.textBox16.Background = (Brush) Brushes.Lime;
          this.textBox17.Background = (Brush) Brushes.Lime;
          this.textBox16.Foreground = (Brush) Brushes.Black;
          this.textBox17.Foreground = (Brush) Brushes.Black;
          this.textBox16.BorderBrush = (Brush) Brushes.Black;
          this.textBox17.BorderBrush = (Brush) Brushes.Black;
        }
        if (this._row != 7)
        {
          this.textBox19.Background = (Brush) Brushes.Black;
          this.textBox20.Background = (Brush) Brushes.Black;
          this.textBox19.Foreground = (Brush) Brushes.Lime;
          this.textBox20.Foreground = (Brush) Brushes.Lime;
          this.textBox19.BorderBrush = (Brush) Brushes.Lime;
          this.textBox20.BorderBrush = (Brush) Brushes.Lime;
        }
        else
        {
          this.textBox19.Background = (Brush) Brushes.Lime;
          this.textBox20.Background = (Brush) Brushes.Lime;
          this.textBox19.Foreground = (Brush) Brushes.Black;
          this.textBox20.Foreground = (Brush) Brushes.Black;
          this.textBox19.BorderBrush = (Brush) Brushes.Black;
          this.textBox20.BorderBrush = (Brush) Brushes.Black;
        }
        if (this._row != 8)
        {
          this.textBox22.Background = (Brush) Brushes.Black;
          this.textBox23.Background = (Brush) Brushes.Black;
          this.textBox22.Foreground = (Brush) Brushes.Lime;
          this.textBox23.Foreground = (Brush) Brushes.Lime;
          this.textBox22.BorderBrush = (Brush) Brushes.Lime;
          this.textBox23.BorderBrush = (Brush) Brushes.Lime;
        }
        else
        {
          this.textBox22.Background = (Brush) Brushes.Lime;
          this.textBox23.Background = (Brush) Brushes.Lime;
          this.textBox22.Foreground = (Brush) Brushes.Black;
          this.textBox23.Foreground = (Brush) Brushes.Black;
          this.textBox22.BorderBrush = (Brush) Brushes.Black;
          this.textBox23.BorderBrush = (Brush) Brushes.Black;
        }
        if (this._row != 9)
        {
          this.textBox25.Background = (Brush) Brushes.Black;
          this.textBox26.Background = (Brush) Brushes.Black;
          this.textBox25.Foreground = (Brush) Brushes.Lime;
          this.textBox26.Foreground = (Brush) Brushes.Lime;
          this.textBox25.BorderBrush = (Brush) Brushes.Lime;
          this.textBox26.BorderBrush = (Brush) Brushes.Lime;
        }
        else
        {
          this.textBox25.Background = (Brush) Brushes.Lime;
          this.textBox26.Background = (Brush) Brushes.Lime;
          this.textBox25.Foreground = (Brush) Brushes.Black;
          this.textBox26.Foreground = (Brush) Brushes.Black;
          this.textBox25.BorderBrush = (Brush) Brushes.Black;
          this.textBox26.BorderBrush = (Brush) Brushes.Black;
        }
        if (this._row != 10)
        {
          this.textBox28.Background = (Brush) Brushes.Black;
          this.textBox29.Background = (Brush) Brushes.Black;
          this.textBox28.Foreground = (Brush) Brushes.Lime;
          this.textBox29.Foreground = (Brush) Brushes.Lime;
          this.textBox28.BorderBrush = (Brush) Brushes.Lime;
          this.textBox29.BorderBrush = (Brush) Brushes.Lime;
        }
        else
        {
          this.textBox28.Background = (Brush) Brushes.Lime;
          this.textBox29.Background = (Brush) Brushes.Lime;
          this.textBox28.Foreground = (Brush) Brushes.Black;
          this.textBox29.Foreground = (Brush) Brushes.Black;
          this.textBox28.BorderBrush = (Brush) Brushes.Black;
          this.textBox29.BorderBrush = (Brush) Brushes.Black;
        }
      }
    }

    private void save_btn_Click(object sender, RoutedEventArgs e)
    {
      this.array2D[0, 0] = this.textBox1.Text;
      this.array2D[0, 1] = this.textBox2.Text;
      this.array2D[0, 2] = this.textBox3.Text;
      this.array2D[1, 0] = this.textBox4.Text;
      this.array2D[1, 1] = this.textBox5.Text;
      this.array2D[1, 2] = this.textBox6.Text;
      this.array2D[2, 0] = this.textBox7.Text;
      this.array2D[2, 1] = this.textBox8.Text;
      this.array2D[2, 2] = this.textBox9.Text;
      this.array2D[3, 0] = this.textBox10.Text;
      this.array2D[3, 1] = this.textBox11.Text;
      this.array2D[3, 2] = this.textBox12.Text;
      this.array2D[4, 0] = this.textBox13.Text;
      this.array2D[4, 1] = this.textBox14.Text;
      this.array2D[4, 2] = this.textBox15.Text;
      this.array2D[5, 0] = this.textBox16.Text;
      this.array2D[5, 1] = this.textBox17.Text;
      this.array2D[5, 2] = this.textBox18.Text;
      this.array2D[6, 0] = this.textBox19.Text;
      this.array2D[6, 1] = this.textBox20.Text;
      this.array2D[6, 2] = this.textBox21.Text;
      this.array2D[7, 0] = this.textBox22.Text;
      this.array2D[7, 1] = this.textBox23.Text;
      this.array2D[7, 2] = this.textBox24.Text;
      this.array2D[8, 0] = this.textBox25.Text;
      this.array2D[8, 1] = this.textBox26.Text;
      this.array2D[8, 2] = this.textBox27.Text;
      this.array2D[9, 0] = this.textBox28.Text;
      this.array2D[9, 1] = this.textBox29.Text;
      this.array2D[9, 2] = this.textBox30.Text;
    }

    private void load_btn_Click(object sender, RoutedEventArgs e)
    {
      this.textBox1.Text = this.array2D[0, 0];
      this.textBox2.Text = this.array2D[0, 1];
      this.textBox3.Text = this.array2D[0, 2];
      this.textBox4.Text = this.array2D[1, 0];
      this.textBox5.Text = this.array2D[1, 1];
      this.textBox6.Text = this.array2D[1, 2];
      this.textBox7.Text = this.array2D[2, 0];
      this.textBox8.Text = this.array2D[2, 1];
      this.textBox9.Text = this.array2D[2, 2];
      this.textBox10.Text = this.array2D[3, 0];
      this.textBox11.Text = this.array2D[3, 1];
      this.textBox12.Text = this.array2D[3, 2];
      this.textBox13.Text = this.array2D[4, 0];
      this.textBox14.Text = this.array2D[4, 1];
      this.textBox15.Text = this.array2D[4, 2];
      this.textBox16.Text = this.array2D[5, 0];
      this.textBox17.Text = this.array2D[5, 1];
      this.textBox18.Text = this.array2D[5, 2];
      this.textBox19.Text = this.array2D[6, 0];
      this.textBox20.Text = this.array2D[6, 1];
      this.textBox21.Text = this.array2D[6, 2];
      this.textBox22.Text = this.array2D[7, 0];
      this.textBox23.Text = this.array2D[7, 1];
      this.textBox24.Text = this.array2D[7, 2];
      this.textBox25.Text = this.array2D[8, 0];
      this.textBox26.Text = this.array2D[8, 1];
      this.textBox27.Text = this.array2D[8, 2];
      this.textBox28.Text = this.array2D[9, 0];
      this.textBox29.Text = this.array2D[9, 1];
      this.textBox30.Text = this.array2D[9, 2];
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/HotMouse;component/hotmouse.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    [SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
    [SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
    [SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          this.HotMouse = (HotMouse1) target;
          this.HotMouse.Loaded += new RoutedEventHandler(this.Window_Loaded);
          this.HotMouse.Closing += new CancelEventHandler(this.Window_Closing);
          break;
        case 2:
          this.rowup_btn = (Button) target;
          this.rowup_btn.Click += new RoutedEventHandler(this.rowup_btn_Click);
          break;
        case 3:
          this.keycap_btn = (Button) target;
          this.keycap_btn.Click += new RoutedEventHandler(this.keycap_btn_Click);
          break;
        case 4:
          this.clearrow_btn = (Button) target;
          this.clearrow_btn.Click += new RoutedEventHandler(this.clearrow_btn_Click);
          break;
        case 5:
          this.rowdown_btn = (Button) target;
          this.rowdown_btn.Click += new RoutedEventHandler(this.rowdown_btn_Click);
          break;
        case 6:
          this.mousecap_btn = (Button) target;
          this.mousecap_btn.LostMouseCapture += new MouseEventHandler(this.mousecap_btn_LostMouseCapture);
          break;
        case 7:
          this.charmodebtn = (Button) target;
          this.charmodebtn.Click += new RoutedEventHandler(this.charmodebtn_Click);
          break;
        case 8:
          this.textBox = (TextBox) target;
          break;
        case 9:
          this.textBox1 = (TextBox) target;
          break;
        case 10:
          this.textBox2 = (TextBox) target;
          break;
        case 11:
          this.textBox3 = (TextBox) target;
          break;
        case 12:
          this.textBox4 = (TextBox) target;
          break;
        case 13:
          this.textBox5 = (TextBox) target;
          break;
        case 14:
          this.textBox6 = (TextBox) target;
          break;
        case 15:
          this.textBox7 = (TextBox) target;
          break;
        case 16:
          this.textBox8 = (TextBox) target;
          break;
        case 17:
          this.textBox9 = (TextBox) target;
          break;
        case 18:
          this.textBox10 = (TextBox) target;
          break;
        case 19:
          this.textBox11 = (TextBox) target;
          break;
        case 20:
          this.textBox12 = (TextBox) target;
          break;
        case 21:
          this.textBox13 = (TextBox) target;
          break;
        case 22:
          this.textBox14 = (TextBox) target;
          break;
        case 23:
          this.textBox15 = (TextBox) target;
          break;
        case 24:
          this.textBox16 = (TextBox) target;
          break;
        case 25:
          this.textBox17 = (TextBox) target;
          break;
        case 26:
          this.textBox18 = (TextBox) target;
          break;
        case 27:
          this.textBox19 = (TextBox) target;
          break;
        case 28:
          this.textBox20 = (TextBox) target;
          break;
        case 29:
          this.textBox21 = (TextBox) target;
          break;
        case 30:
          this.textBox22 = (TextBox) target;
          break;
        case 31:
          this.textBox23 = (TextBox) target;
          break;
        case 32:
          this.textBox24 = (TextBox) target;
          break;
        case 33:
          this.textBox25 = (TextBox) target;
          break;
        case 34:
          this.textBox26 = (TextBox) target;
          break;
        case 35:
          this.textBox27 = (TextBox) target;
          break;
        case 36:
          this.textBox28 = (TextBox) target;
          break;
        case 37:
          this.textBox29 = (TextBox) target;
          break;
        case 38:
          this.textBox30 = (TextBox) target;
          break;
        case 39:
          this.label = (Label) target;
          break;
        case 40:
          this.label1 = (Label) target;
          break;
        case 41:
          this.label2 = (Label) target;
          break;
        case 42:
          this.label3 = (Label) target;
          break;
        case 43:
          this.button = (Button) target;
          this.button.Click += new RoutedEventHandler(this.button_Click);
          break;
        case 44:
          this.button1 = (Button) target;
          this.button1.Click += new RoutedEventHandler(this.button1_Click);
          break;
        case 45:
          this.button2 = (Button) target;
          this.button2.Click += new RoutedEventHandler(this.button2_Click);
          break;
        case 46:
          this.button3 = (Button) target;
          this.button3.Click += new RoutedEventHandler(this.button3_Click);
          break;
        case 47:
          this.button4 = (Button) target;
          this.button4.Click += new RoutedEventHandler(this.button4_Click);
          break;
        case 48:
          this.button5 = (Button) target;
          this.button5.Click += new RoutedEventHandler(this.button5_Click);
          break;
        case 49:
          this.button6 = (Button) target;
          this.button6.Click += new RoutedEventHandler(this.button6_Click);
          break;
        case 50:
          this.button7 = (Button) target;
          this.button7.Click += new RoutedEventHandler(this.button7_Click);
          break;
        case 51:
          this.button8 = (Button) target;
          this.button8.Click += new RoutedEventHandler(this.button8_Click);
          break;
        case 52:
          this.button9 = (Button) target;
          this.button9.Click += new RoutedEventHandler(this.button9_Click);
          break;
        case 53:
          this.save_btn = (Button) target;
          this.save_btn.Click += new RoutedEventHandler(this.save_btn_Click);
          break;
        case 54:
          this.load_btn = (Button) target;
          this.load_btn.Click += new RoutedEventHandler(this.load_btn_Click);
          break;
        case 55:
          this.textBlock = (TextBlock) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    internal struct Win32Point
    {
      public int X;
      public int Y;
    }
  }
}
