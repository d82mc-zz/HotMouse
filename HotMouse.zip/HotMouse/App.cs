﻿// Decompiled with JetBrains decompiler
// Type: HotMouse.App
// Assembly: HotMouse, Version=0.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: BCDF7B6D-2DF3-46E7-87F7-42EECC13BAFB
// Assembly location: C:\Users\d82mc\AppData\Local\Apps\2.0\JOHL5TOD.DEP\43HDHM9P.HR1\hotm..tion_a6765aedf8daf2cc_0002.0003_8a45d257b7895c72\HotMouse.exe

using System;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.Windows;

namespace HotMouse
{
  public class App : Application
  {
    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      this.StartupUri = new Uri("HotMouse.xaml", UriKind.Relative);
    }

    [STAThread]
    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public static void Main()
    {
      App app = new App();
      app.InitializeComponent();
      app.Run();
    }
  }
}
